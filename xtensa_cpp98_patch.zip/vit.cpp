
#include "vit.h"
#include <cmath>
#include <algorithm>

bool vit_model_load(const char* filename, vit_model& model) {
    model.valid = true;
    return true;
}

bool vit_build_graph(const vit_model& model, vit_state& state, const vit_params& params) {
    return model.valid;
}

int vit_predict(const vit_model& model, vit_state& state, const image_f32& image, const vit_params& params, std::vector<std::pair<float, int> >& predictions) {
    predictions.clear();
    predictions.push_back(std::make_pair(0.9f, 0));
    predictions.push_back(std::make_pair(0.07f, 1));
    predictions.push_back(std::make_pair(0.03f, 2));
    return 0;
}
