#include "vit.h"
#include <iostream>

int main() {
    vit_model model;
    vit_state state;
    vit_params params;

    params.topk = 3;
    params.model = "model.bin";
    params.fname_inp = "image.jpg";

    std::vector<std::pair<float, int> > predictions;

    if (!vit_model_load(params.model.c_str(), model)) {
        std::cerr << "Failed to load model." << std::endl;
        return 1;
    }

    if (!vit_build_graph(model, state, params)) {
        std::cerr << "Failed to build graph." << std::endl;
        return 1;
    }

    image_f32 image;
    if (!image_f32_load_from_file(params.fname_inp.c_str(), image)) {
        std::cerr << "Failed to load image." << std::endl;
        return 1;
    }

    int prediction = vit_predict(model, state, image, params, predictions);

    std::cout << "Top prediction: " << prediction << std::endl;
    for (size_t i = 0; i < predictions.size(); ++i) {
        std::cout << "Class " << predictions[i].second << " with score " << predictions[i].first << std::endl;
    }

    return 0;
}
