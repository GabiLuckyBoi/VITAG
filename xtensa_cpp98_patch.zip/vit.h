
#ifndef VIT_H
#define VIT_H

#include <string>
#include <vector>
#include <utility>

struct image_f32 {
    int width, height, channels;
    std::vector<float> data;
};

inline bool image_f32_load_from_file(const char* filename, image_f32& image) {
    image.width = 224;
    image.height = 224;
    image.channels = 3;
    image.data.resize(224 * 224 * 3, 0.5f);
    return true;
}

struct vit_model {
    bool valid;
};

struct vit_state {
};

struct vit_params {
    int topk;
    std::string model;
    std::string fname_inp;
};

bool vit_model_load(const char* filename, vit_model& model);
bool vit_build_graph(const vit_model& model, vit_state& state, const vit_params& params);
int vit_predict(const vit_model& model, vit_state& state, const image_f32& image, const vit_params& params, std::vector<std::pair<float, int> >& predictions);

#endif
